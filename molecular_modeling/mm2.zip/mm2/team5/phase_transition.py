import subprocess
import numpy as np

k = 1000

T = [np.linspace(0.0001, 0.1, 100)]


