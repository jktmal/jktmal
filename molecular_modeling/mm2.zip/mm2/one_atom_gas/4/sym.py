import os
import numpy as np

symulacje = np.linspace(0.001, 15, 20, dtype='float')
print(str(symulacje[1]))
for i in range(len(symulacje)):
    bashCommand = "python3 main.py -n 4 -k 20000 -dt 0.0001 -T "+str(symulacje[i])+ " -o "+str(i+1)
    os.system(bashCommand)

