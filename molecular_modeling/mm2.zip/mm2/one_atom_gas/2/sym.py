import os
import numpy as np

symulacje = np.linspace(0.001, 50, 20, dtype='float')
print(str(symulacje[1]))
for i in range(len(symulacje)):
    bashCommand = "python3 main.py -n 5 -k 5000 -dt 0.0001 -T "+str(symulacje[i])+ " -o "+str(i+1)
    os.system(bashCommand)

