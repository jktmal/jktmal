import numpy as np
from matplotlib import pylab as py

A = np.zeros((5000, 20), dtype='float')
for i in range(1, 21):
	A[:, i-1] = np.loadtxt('energy'+str(i)+'.txt')

sr = np.zeros(20, dtype='float')
odch = np.zeros(20, dtype='float')
T = np.linspace(0.001, 15, 20)

#sr[0] = np.mean(A[1300:, 0])
#odch[0] = np.std(A[1300:, 0], ddof=1)

sr[0] = np.mean(A[700:, 1])
odch[0] = np.std(A[700:, 1], ddof=1)

sr[1] = np.mean(A[1000:, 2])
odch[1] = np.std(A[1000:, 2], ddof=1)
sr[2] = np.mean(A[1000:, 3])
odch[2] = np.std(A[1000:, 3], ddof=1)
sr[3] = np.mean(A[2500:, 4])
odch[3] = np.std(A[2500:, 4], ddof=1)
sr[4] = np.mean(A[1200:, 5])
odch[4] = np.std(A[1200:, 5], ddof=1)
sr[5] = np.mean(A[1000:, 6])
odch[5] = np.std(A[1000:, 6], ddof=1)
sr[6] = np.mean(A[1100:, 7])
odch[6] = np.std(A[1100:, 7], ddof=1)
sr[7] = np.mean(A[1300:, 8])
odch[7] = np.std(A[1300:, 8], ddof=1)
sr[8] = np.mean(A[900:, 9])
odch[8] = np.std(A[900:, 9], ddof=1)
sr[9] = np.mean(A[800:, 9])
odch[9] = np.std(A[800:, 9], ddof=1)

sr[10] = np.mean(A[800:, 10])
odch[10] = np.std(A[800:, 10], ddof=1)
sr[11] = np.mean(A[800:, 11])
odch[11] = np.std(A[800:, 11], ddof=1)
sr[12] = np.mean(A[900:, 12])
odch[12] = np.std(A[900:, 12], ddof=1)
sr[13] = np.mean(A[1000:, 13])
odch[13] = np.std(A[1000:, 13], ddof=1)
sr[14] = np.mean(A[800:, 14])
odch[14] = np.std(A[800:, 14], ddof=1)
sr[15] = np.mean(A[900:, 15])
odch[15] = np.std(A[900:, 15], ddof=1)
sr[16] = np.mean(A[800:, 16])
odch[16] = np.std(A[800:, 16], ddof=1)
sr[17] = np.mean(A[700:, 17])
odch[17] = np.std(A[700:, 17], ddof=1)
sr[18] = np.mean(A[1800:, 18])
odch[18] = np.std(A[1800:, 18], ddof=1)
sr[19] = np.mean(A[1600:, 19])
odch[19] = np.std(A[1600:, 19], ddof=1)



py.plot(T, sr, 'bo')
py.show()
py.plot(T, odch, 'bo')
py.show()
